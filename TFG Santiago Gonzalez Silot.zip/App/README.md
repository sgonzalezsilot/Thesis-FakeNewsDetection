# WebAppTFG
App web del Trabajo Fin de Grado de **Santiago González Silot**

* En el fichero Fine-Tuning.ipynb se realiza el análisis de los 2 *datasets* junto a las distintas pruebas realizadas en el trabajo.
* El resto de fichero corresponden a la app web del trabajo.
